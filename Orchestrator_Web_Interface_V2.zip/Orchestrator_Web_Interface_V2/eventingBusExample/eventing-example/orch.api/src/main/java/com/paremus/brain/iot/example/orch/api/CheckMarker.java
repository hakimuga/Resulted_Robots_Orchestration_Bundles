package com.paremus.brain.iot.example.orch.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class CheckMarker extends BrainIoTEvent {

	public int robotid;
	public int robot;
}
