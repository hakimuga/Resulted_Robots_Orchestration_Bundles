package com.paremus.brain.iot.example.robotA.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class QueryStateValueReturn extends BrainIoTEvent{
	public int value;
}
