package org.lib.markersinsight;

public class Orientation {

	
	double y = 0.99827329586809;
	double x = -0.0020421436667357722;
	double z = 0.03078211091399566;
	double w = -0.0499871788920295;
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getZ() {
		return z;
	}
	public void setZ(double z) {
		this.z = z;
	}
	public double getW() {
		return w;
	}
	public void setW(double w) {
		this.w = w;
	}
	
	
	
}
