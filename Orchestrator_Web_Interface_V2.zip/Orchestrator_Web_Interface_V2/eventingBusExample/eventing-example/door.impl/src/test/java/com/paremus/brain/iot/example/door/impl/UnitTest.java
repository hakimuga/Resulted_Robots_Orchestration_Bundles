package com.paremus.brain.iot.example.door.impl;

import org.junit.Test;

public class UnitTest {
    
    @Test
    public void testSomething() {
        //TODO add an implementation
    }
    
}
