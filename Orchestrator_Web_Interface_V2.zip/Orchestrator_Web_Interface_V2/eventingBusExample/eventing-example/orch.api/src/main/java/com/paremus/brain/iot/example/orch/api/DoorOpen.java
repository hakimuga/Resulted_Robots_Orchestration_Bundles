package com.paremus.brain.iot.example.orch.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class DoorOpen extends BrainIoTEvent {

}