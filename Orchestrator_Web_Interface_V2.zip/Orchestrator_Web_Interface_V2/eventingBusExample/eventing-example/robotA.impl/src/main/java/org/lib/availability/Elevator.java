package org.lib.availability;

public class Elevator {
	
	String position ="unknown";
	String state ="idle";
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	

}
