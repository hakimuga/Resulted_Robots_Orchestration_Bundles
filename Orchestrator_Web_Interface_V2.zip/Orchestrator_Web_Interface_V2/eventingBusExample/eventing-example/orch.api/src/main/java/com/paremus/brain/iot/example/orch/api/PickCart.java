package com.paremus.brain.iot.example.orch.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class PickCart extends BrainIoTEvent {

	public int cart;
}
