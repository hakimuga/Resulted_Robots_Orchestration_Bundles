package port;

import type.*;

public class ePort extends Port { 
public ePort(){  

}
}
