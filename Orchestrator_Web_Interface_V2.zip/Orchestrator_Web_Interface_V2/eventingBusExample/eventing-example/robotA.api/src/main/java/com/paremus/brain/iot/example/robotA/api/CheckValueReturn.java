package com.paremus.brain.iot.example.robotA.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class CheckValueReturn extends BrainIoTEvent {

	
	public int value;
}
