/* Copyright 2019 Paremus, Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */

@org.osgi.annotation.bundle.Export
@org.osgi.annotation.versioning.Version("0.0.1")
package eu.brain.iot.eventing.annotation;