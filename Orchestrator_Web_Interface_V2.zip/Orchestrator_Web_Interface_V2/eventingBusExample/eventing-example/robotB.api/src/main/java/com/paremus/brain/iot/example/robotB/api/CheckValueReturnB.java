package com.paremus.brain.iot.example.robotB.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class CheckValueReturnB extends BrainIoTEvent {

	
	public int value;
}
