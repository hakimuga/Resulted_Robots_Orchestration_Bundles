# ROBOT SYSTEM ORCHESTRATION

**Five bundles are now available for deployment**
*  1- Import the Maven files located in  Orchestrator_Web_Interface directory 
*  2- Locate single-framework-example and lunch debug.bndrun
*  3- Click run OSGi
*  4- Go to http://localhost:8080/main
*  5- Type the ip address and port (IP:10.8.0.50 PORT:8080)
*  6- If the page returned =>" Host : 10.8.0.50 is reachable "  Then the server is available and robots will start 