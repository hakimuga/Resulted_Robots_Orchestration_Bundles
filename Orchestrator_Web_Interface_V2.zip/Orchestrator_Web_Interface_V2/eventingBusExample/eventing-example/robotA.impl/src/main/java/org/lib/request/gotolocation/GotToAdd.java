package org.lib.request.gotolocation;

public class GotToAdd {

	Procedure procedure = new Procedure();

	public Procedure getProcedure() {
		return procedure;
	}

	public void setProcedure(Procedure procedure) {
		this.procedure = procedure;
	}
	
	
}
