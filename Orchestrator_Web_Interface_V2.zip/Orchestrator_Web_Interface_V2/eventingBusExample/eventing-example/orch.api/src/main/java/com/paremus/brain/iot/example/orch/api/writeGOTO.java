package com.paremus.brain.iot.example.orch.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class writeGOTO extends BrainIoTEvent {

	
	public int mission;
	
}
