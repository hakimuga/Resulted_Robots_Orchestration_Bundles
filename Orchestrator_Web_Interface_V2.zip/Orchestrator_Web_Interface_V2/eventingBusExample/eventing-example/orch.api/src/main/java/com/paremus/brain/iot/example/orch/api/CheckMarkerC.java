package com.paremus.brain.iot.example.orch.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class CheckMarkerC extends BrainIoTEvent {

	public int robotid;
	public int robot;
}
